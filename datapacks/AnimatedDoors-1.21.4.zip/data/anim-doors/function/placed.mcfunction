scoreboard players reset @s _betdor_1
scoreboard players reset @s _betdor_2
scoreboard players reset @s _betdor_3
scoreboard players reset @s _betdor_4
scoreboard players reset @s _betdor_5
scoreboard players reset @s _betdor_6
scoreboard players reset @s _betdor_7
scoreboard players reset @s _betdor_8
scoreboard players reset @s _betdor_9
scoreboard players reset @s _betdor_10
scoreboard players reset @s _betdor_11
scoreboard players reset @s _betdor_12
scoreboard players reset @s _betdor_13
scoreboard players reset @s _betdor_14
scoreboard players reset @s _betdor_15
scoreboard players reset @s _betdor_16
scoreboard players reset @s _betdor_17
scoreboard players reset @s _betdor_18
scoreboard players reset @s _betdor_19
scoreboard players reset @s _betdor_20
scoreboard players reset @s _betdor_21

function anim-doors:search

