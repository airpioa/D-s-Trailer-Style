tag @s add _betdor_skip_check

execute if block ~ ~ ~ minecraft:oak_door[half=lower] run scoreboard players set type_check _betdor 1
execute if block ~ ~ ~ minecraft:spruce_door[half=lower] run scoreboard players set type_check _betdor 2
execute if block ~ ~ ~ minecraft:birch_door[half=lower] run scoreboard players set type_check _betdor 3
execute if block ~ ~ ~ minecraft:jungle_door[half=lower] run scoreboard players set type_check _betdor 4
execute if block ~ ~ ~ minecraft:acacia_door[half=lower] run scoreboard players set type_check _betdor 5
execute if block ~ ~ ~ minecraft:dark_oak_door[half=lower] run scoreboard players set type_check _betdor 6
execute if block ~ ~ ~ minecraft:crimson_door[half=lower] run scoreboard players set type_check _betdor 7
execute if block ~ ~ ~ minecraft:warped_door[half=lower] run scoreboard players set type_check _betdor 8
execute if block ~ ~ ~ minecraft:cherry_door[half=lower] run scoreboard players set type_check _betdor 10
execute if block ~ ~ ~ minecraft:bamboo_door[half=lower] run scoreboard players set type_check _betdor 11
execute if block ~ ~ ~ minecraft:mangrove_door[half=lower] run scoreboard players set type_check _betdor 12
execute if block ~ ~ ~ minecraft:copper_door[half=lower] run scoreboard players set type_check _betdor 13
execute if block ~ ~ ~ minecraft:waxed_copper_door[half=lower] run scoreboard players set type_check _betdor 13
execute if block ~ ~ ~ minecraft:exposed_copper_door[half=lower] run scoreboard players set type_check _betdor 15
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_door[half=lower] run scoreboard players set type_check _betdor 15
execute if block ~ ~ ~ minecraft:weathered_copper_door[half=lower] run scoreboard players set type_check _betdor 17
execute if block ~ ~ ~ minecraft:waxed_weathered_copper_door[half=lower] run scoreboard players set type_check _betdor 17
execute if block ~ ~ ~ minecraft:oxidized_copper_door[half=lower] run scoreboard players set type_check _betdor 19
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_door[half=lower] run scoreboard players set type_check _betdor 19
execute if block ~ ~ ~ minecraft:pale_oak_door[half=lower] run scoreboard players set type_check _betdor 20
execute if block ~ ~ ~ minecraft:iron_door[half=lower] run scoreboard players set type_check _betdor 9

execute if block ~ ~ ~ #anim-doors:valid_door[open=false] run scoreboard players set open_check _betdor 0
execute if block ~ ~ ~ #anim-doors:valid_door[open=true] run scoreboard players set open_check _betdor 1

execute if block ~ ~ ~ #anim-doors:valid_door[hinge=left] run scoreboard players set hinge_type _betdor 0
execute if block ~ ~ ~ #anim-doors:valid_door[hinge=right] run scoreboard players set hinge_type _betdor 1

execute if block ~ ~ ~ #anim-doors:valid_door[facing=north] run scoreboard players set facing _betdor 0
execute if block ~ ~ ~ #anim-doors:valid_door[facing=south] run scoreboard players set facing _betdor 1
execute if block ~ ~ ~ #anim-doors:valid_door[facing=east] run scoreboard players set facing _betdor 2
execute if block ~ ~ ~ #anim-doors:valid_door[facing=west] run scoreboard players set facing _betdor 3

fill ~ ~1 ~ ~ ~ ~ air replace #anim-doors:valid_door

execute if score type_check _betdor matches 1 run function anim-doors:change/oak
execute if score type_check _betdor matches 2 run function anim-doors:change/spruce
execute if score type_check _betdor matches 3 run function anim-doors:change/birch
execute if score type_check _betdor matches 4 run function anim-doors:change/jungle
execute if score type_check _betdor matches 5 run function anim-doors:change/acacia
execute if score type_check _betdor matches 6 run function anim-doors:change/dark_oak
execute if score type_check _betdor matches 7 run function anim-doors:change/crimson
execute if score type_check _betdor matches 8 run function anim-doors:change/warped
execute if score type_check _betdor matches 10 run function anim-doors:change/cherry
execute if score type_check _betdor matches 11 run function anim-doors:change/bamboo
execute if score type_check _betdor matches 12 run function anim-doors:change/mangrove
execute if score type_check _betdor matches 13 run function anim-doors:change/copper
execute if score type_check _betdor matches 15 run function anim-doors:change/exposed_copper
execute if score type_check _betdor matches 17 run function anim-doors:change/weathered_copper
execute if score type_check _betdor matches 19 run function anim-doors:change/oxidized_copper
execute if score type_check _betdor matches 20 run function anim-doors:change/pale_oak
execute if score type_check _betdor matches 9 run function anim-doors:change/iron

function anim-doors:animation