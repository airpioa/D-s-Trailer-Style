# every time the pack is reloaded this runs
scoreboard objectives add _betdor_1 minecraft.used:minecraft.oak_door
scoreboard objectives add _betdor_2 minecraft.used:minecraft.spruce_door
scoreboard objectives add _betdor_3 minecraft.used:minecraft.birch_door
scoreboard objectives add _betdor_4 minecraft.used:minecraft.acacia_door
scoreboard objectives add _betdor_5 minecraft.used:minecraft.jungle_door
scoreboard objectives add _betdor_6 minecraft.used:minecraft.dark_oak_door
scoreboard objectives add _betdor_7 minecraft.used:minecraft.crimson_door
scoreboard objectives add _betdor_8 minecraft.used:minecraft.warped_door
scoreboard objectives add _betdor_10 minecraft.used:minecraft.cherry_door
scoreboard objectives add _betdor_11 minecraft.used:minecraft.bamboo_door
scoreboard objectives add _betdor_12 minecraft.used:minecraft.mangrove_door
scoreboard objectives add _betdor_13 minecraft.used:minecraft.copper_door
scoreboard objectives add _betdor_14 minecraft.used:minecraft.waxed_copper_door
scoreboard objectives add _betdor_15 minecraft.used:minecraft.exposed_copper_door
scoreboard objectives add _betdor_16 minecraft.used:minecraft.waxed_exposed_copper_door
scoreboard objectives add _betdor_17 minecraft.used:minecraft.weathered_copper_door
scoreboard objectives add _betdor_18 minecraft.used:minecraft.waxed_weathered_copper_door
scoreboard objectives add _betdor_19 minecraft.used:minecraft.oxidized_copper_door
scoreboard objectives add _betdor_20 minecraft.used:minecraft.waxed_oxidized_copper_door
scoreboard objectives add _betdor_21 minecraft.used:minecraft.pale_oak_door
scoreboard objectives add _betdor_9 minecraft.used:minecraft.iron_door


scoreboard objectives add _betdor dummy
scoreboard objectives add _betdor_state dummy

scoreboard objectives add _betdor_close_r dummy
scoreboard objectives add _betdor_open_r dummy

scoreboard objectives add _betdor_air dummy



