# 20tps
execute as @e[type=minecraft:armor_stand,tag=_betdor_marker] at @s run function anim-doors:as_marker
execute as @a[gamemode=!spectator] at @s run function anim-doors:as_player