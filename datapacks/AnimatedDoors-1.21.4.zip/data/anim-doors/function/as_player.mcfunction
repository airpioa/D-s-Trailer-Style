execute if score @s _betdor_1 matches 1.. run function anim-doors:placed
execute if score @s _betdor_2 matches 1.. run function anim-doors:placed
execute if score @s _betdor_3 matches 1.. run function anim-doors:placed
execute if score @s _betdor_4 matches 1.. run function anim-doors:placed
execute if score @s _betdor_5 matches 1.. run function anim-doors:placed
execute if score @s _betdor_6 matches 1.. run function anim-doors:placed
execute if score @s _betdor_7 matches 1.. run function anim-doors:placed
execute if score @s _betdor_8 matches 1.. run function anim-doors:placed
execute if score @s _betdor_9 matches 1.. run function anim-doors:placed
execute if score @s _betdor_10 matches 1.. run function anim-doors:placed
execute if score @s _betdor_11 matches 1.. run function anim-doors:placed
execute if score @s _betdor_12 matches 1.. run function anim-doors:placed
execute if score @s _betdor_13 matches 1.. run function anim-doors:placed
execute if score @s _betdor_14 matches 1.. run function anim-doors:placed
execute if score @s _betdor_15 matches 1.. run function anim-doors:placed
execute if score @s _betdor_16 matches 1.. run function anim-doors:placed
execute if score @s _betdor_17 matches 1.. run function anim-doors:placed
execute if score @s _betdor_18 matches 1.. run function anim-doors:placed
execute if score @s _betdor_19 matches 1.. run function anim-doors:placed
execute if score @s _betdor_20 matches 1.. run function anim-doors:placed
execute if score @s _betdor_21 matches 1.. run function anim-doors:placed

scoreboard players set raycast _betdor 6
execute anchored eyes positioned ^ ^ ^ run function anim-doors:raycast